#!/usr/bin/env python
'''
Created on Apr 7,2014

@author: Neal
'''
import os
inputFile=open("MSI_Day3_2_k_40.txt","r")
outputFile=open("MSI_Day3_2_k_40_filtered.txt","w")
for line in inputFile.readlines():
    tempLine=line[0:-1].split(' ')
    if int(tempLine[1])>9:
        outputFile.write(line) 
inputFile.close()
outputFile.close()
